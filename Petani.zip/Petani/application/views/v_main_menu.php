<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Petani Kode: Programmer Pengguna Linux</title>
  </head>
  <body class="bg-light">
    <!--kode disini -->
    <!--navbar -->
    <div>
    	<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #008080;">
    		<div class="container">
    			<a class="navbar-brand font-weight-bold" href="http://192.168.64.2/Petani/">
			  	<img src="https://d33wubrfki0l68.cloudfront.net/c68e72d9d907e973e14791cdefd54fcd726a5a13/2c870/img/logo.svg" height="32" class="d-inline-block align-top" alt="Logo"> Petanikode
			  </a>
			  <!-- Done .................................................... -->
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="navbar-toggler-icon"></span>
			  </button>
			  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			    <ul class="navbar-nav mr-auto">
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url('Petani/PHP'); ?>">PHP</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url('Petani/Java'); ?>">Java</a>
			      </li>
			      <li class="nav-item">
			      	<a class="nav-link" href="<?= base_url('Petani/Python'); ?>">Python</a>
			      </li>
			      <li class="nav-item">
			      	<a class="nav-link" href="<?= base_url('Petani/Javascript'); ?>">Javascript</a>
			      </li>
			      <li class="nav-item">
			      	<a class="nav-link" href="<?= base_url('Petani/Git'); ?>">Git</a>
			      </li>
			      <li class="nav-item d-none d-lg-block disabled">
			      	<span class="nav-link disabled">|</span>
			      </li>
			      <li class="nav-item">
			      	<a class="nav-link" href="https://www.youtube.com/petanikode" target="_blank"> Video</a>
			      </li>
			      <li class="nav-item">
			      	<a class="nav-link" href="https://www.tees.co.id/stores/petanikode/" target="_blank">Produk</a>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Jobs
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          <a class="dropdown-item" href="https://id.jooble.org/lowongan-kerja-programmer" title="lowongan kerja programmer" target="_blank">Loker Programmer</a>
			          <a class="dropdown-item" href="http://projects.id/petani_kode" title="Remote Jobs untuk Freelancer" target="_blank">Remote Jobs</a>			          
			        </div>
			      </li>
			    </ul>
			    <form class="form-inline my-2 my-lg-0" action="https://www.petanikode.com/search/">
			      <input class="form-control mr-sm-2" type="text" name="q" placeholder="Kata Kunci" aria-label="Search">
			      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="background-color:#17a2b8; border-color:#17a2b8; color:#fff;">Cari</button>
			    </form>
			  </div>
    		</div>
    	</nav>
    </div>
<!--navbar................................................................................................................................................... -->
	<header>
	    <div>
	    	<div class="jumbotron jumbotron-fluid bg-dark">
			  <div class="container">
			  	<div class="row">
			  		<div class="col" style="color:#fff;">
				    	<h1 class="display-4 font-weight-normal" style="font-size: 45px">Programmer Pengguna Linux</h1>
				    	<p class="lead font-weight-normal">Belajar Pemrograman Apapun Menggunakan Linux</p>
			    	</div>
			  	</div>
			  	</div>
			</div>
	    </div>
	</header>


<!--jumbotron..................................................................................................................................................-->
    <article class="card-post my-5">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-6 col-lg-4 mb-4 d-flex">
    				<div class="card card-shadow"> 
    					<a href="https://www.petanikode.com/ionic-untuk-pemula/">
    						<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/022d8d5ac80b86904278d445c56f069be81500ed/9d6a2/img/ionic/ionic.png" data-src="https://d33wubrfki0l68.cloudfront.net/022d8d5ac80b86904278d445c56f069be81500ed/9d6a2/img/ionic/ionic.png" alt="Belajar Membuat Aplikasi Android Menggunakan Ionic Framework (untuk Pemula)">	
    						</img>
    					</a>
    					<div class="card-body">
    						<h5 class="card-title">
    							<a class="text-dark" href="/ionic-untuk-pemula/">Belajar Membuat Aplikasi Android Menggunakan Ionic Framework (untuk Pemula)
    							</a>
    						</h5>
    					</div>
    				</div>
    			</div>
	    		<div class="col-md-6 col-lg-4 mb-4 d-flex">
	    			<div class="card card-shadow">
	    				<a href="/netbeans10/">
	    					<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/72a519f0c3971a2b78f473ee7a0052301da057b0/1c6cd/img/netbeans/netbeans.png" data-src="https://d33wubrfki0l68.cloudfront.net/72a519f0c3971a2b78f473ee7a0052301da057b0/1c6cd/img/netbeans/netbeans.png" alt="Cara Install Netbeans 10 di Linux">
	    				</a>
	    				<div class="card-body">
	    					<h5 class="card-title">
	    						<a class="text-dark" href="/netbeans10/">Cara Install Netbeans 10 di Linux</a>
	    					</h5>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-md-6 col-lg-4 mb-4 d-flex">
	    			<div class="card card-shadow">
	    				<a href="/flutter-widget/">
	    					<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" data-src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" alt="Tutorial Flutter #5: Belajar Menggunakan Widget Dasar dan Widget Layout">
	    				</a>
	    				<div class="card-body">
	    					<h5 class="card-title">
	    						<a class="text-dark" href="/flutter-widget/">Tutorial Flutter #5: Belajar Menggunakan Widget Dasar dan Widget Layout</a>
	    					</h5>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-md-6 col-lg-4 mb-4 d-flex">
	    			<div class="card card-shadow">
	    				<a href="/flutter-dasar/">
	    					<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" data-src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" alt="Tutorial Flutter #4: Memahami Struktur Dasar Project Aplikasi Flutter">
	    				</a>
	    				<div class="card-body">
	    					<h5 class="card-title">
	    						<a class="text-dark" href="/flutter-dasar/">Tutorial Flutter #4: Memahami Struktur Dasar Project Aplikasi Flutter</a>
	    					</h5>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-md-6 col-lg-4 mb-4 d-flex">
	    			<div class="card card-shadow">
	    				<a href="/flutter-android-studio/">
	    					<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" data-src="https://d33wubrfki0l68.cloudfront.net/31dbe5bba9788ba6369caa6a54467e6ca1aa7fc4/0d322/img/flutter/flutter.png" alt="Tutorial Flutter #3: Cara Menggunakan Android Studio untuk Coding Flutter">
	    				</a>
	    				<div class="card-body">
	    					<h5 class="card-title">
	    						<a class="text-dark" href="/flutter-android-studio/">Tutorial Flutter #3: Cara Menggunakan Android Studio untuk Coding Flutter</a></h5>
	    					</div>
	    				</div>
	    		</div>
	    		<div class="col-md-6 col-lg-4 mb-4 d-flex">
	    			<div class="card card-shadow">
	    				<a href="/python-mysql/">
	    					<img class="card-img-top lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/cb102418724c0c1c346323d8231a70c0a6905007/4fff0/img/python/mysql/python-mysql.png" data-src="https://d33wubrfki0l68.cloudfront.net/cb102418724c0c1c346323d8231a70c0a6905007/4fff0/img/python/mysql/python-mysql.png" alt="Tutorial Python dan MySQL: Membuat Aplikasi CRUDS Berbasis Teks">
	    				</a>
	    				<div class="card-body">
	    					<h5 class="card-title">
	    						<a class="text-dark" href="/python-mysql/">Tutorial Python dan MySQL: Membuat Aplikasi CRUDS Berbasis Teks</a>
	    					</h5>
	    				</div>
	    			</div>
	    		</div>
    		</div>
    	</div>
    	
    	<div class="row">
    		<div class="col-12 mt-4">
    			<nav aria-label="Page navigation">
    				<ul class="pagination">
    					<li class="page-item">
    						<a class="page-link" href="/" aria-label="First">
    							<span aria-hidden="true">««</span>
    						</a>
    					</li>
    					<li class="disabled page-item">
    						<a class="page-link" href="" aria-label="Previous">
    						<span aria-hidden="true">«</span>
	    					</a>
	    				</li>
	    				<li class="active page-item"><a class="page-link" href="/">1</a>
	    				</li>
	    				<li>
	    					<a class="page-link" href="/page/2/">2</a>
	    				</li>
	    				<li>
	    					<a class="page-link" href="/page/3/">3</a>
	    				</li>
	    				<li class="disabled page-item">
	    					<a class="page-link" href="#">
	    						<span aria-hidden="true">…</span>
	    					</a>
	    				</li>
	    				<li>
	    					<a class="page-link" href="/page/55/">55</a>
	    				</li>
	    				<li>
	    					<a class="page-link" href="/page/2/" aria-label="Next">
	    						<span aria-hidden="true">»</span>
	    					</a>
	    				</li>
	    				<li class="page-item">
	    					<a class="page-link" href="/page/55/" aria-label="Last"><span aria-hidden="true">»»</span>
	    					</a>
	    				</li>
	    			</ul>
	    		</nav>
	    	</div>
	    </div>
    </article>
<!-- card .............................................................................-->
	<section>
	<div class="jumbotron jumbotron-fluid mb-0">
		<div class="container">
			<div class="row">
				<div class="col">
					<p class="lead">Masukan email kamu biar tidak ketinggalan update dari <b>Petani Kode</b>...</p><p></p>
					<div id="mlb2-6053117" class="ml-subscribe-form ml-subscribe-form-6053117">
						<div class="ml-vertical-align-center">
							<div class="subscribe-form ml-block-success" style="display:none">
								<div class="form-section alert alert-success">Thank you! You have successfully subscribed to our newsletter.
								</div>
							</div>
							<form class="ml-block-form form-inline my-2 my-lg-0" action="https://app.mailerlite.com/webforms/submit/m6b0m1" data-id="554721" data-code="m6b0m1" method="post" target="_blank">
								<div class="subscribe-form horizontal"><div class="form-section horizontal">
									<div class="form-group ml-field-email ml-validate-required ml-validate-email">
										<input type="email" name="fields[email]" class="form-control mr-sm-2" placeholder="email@contoh.com" autocomplete="email" x-autocompletetype="email" spellcheck="false" autocapitalize="off" autocorrect="off">
								<button type="submit" class="primary btn btn-info my-2 my-sm-0">Berlangganan</button>
									</div>
								</div>
								<div class="form-section horizontal ml-button-position mt-4">
									<span disabled="" style="display:none" class="loading">
										<img src="https://static.mailerlite.com/images/rolling.gif" width="20" height="20" style="width:20px;height:20px" alt="rolling"></span>
									</div>
									<div class="clearfix" style="clear:both">
									</div>
									<input type="hidden" name="ml-submit" value="1">
								</div>
							</form>
							<script>
							function ml_webform_success_6053117(){
								var $=ml_jQuery||jQuery;$('.ml-subscribe-form-6053117 .ml-block-success').show();$('.ml-subscribe-form-6053117 .ml-block-form').hide();};
							</script>
						</div>
					</div>
					<script type="text/javascript" src="https://static.mailerlite.com/js/w/webforms.min.js?v3772b61f1ec61c541c401d4eadfdd02f">
					</script><p></p><p>Atau ikuti melalui:</p>
					<div>
						<a class="mr-2" href="https://www.facebook.com/petanikode">
							<img src="https://d33wubrfki0l68.cloudfront.net/fd39898deb98d9f61bd2d228282663bebbf50692/20304/img/icon/entypo/entypo-social/facebook-with-circle.svg" width="32" height="32" alt="Facebook">
						</a>
							<a class="mr-2" href="https://twitter.com/petanikode">
								<img src="https://d33wubrfki0l68.cloudfront.net/117e196e37673784e0abef5b371f36847e6fcfdd/aa65c/img/icon/entypo/entypo-social/twitter-with-circle.svg" width="32" height="32" alt="Twitter"></a>
							<a class="mr-2" href="https://t.me/petanikode">
								<img src="https://d33wubrfki0l68.cloudfront.net/326ccb9e094d0e772025328a93f75da2850c46fd/3fa06/img/icon/entypo/entypo-social/telegram-with-circle.svg" width="32" height="32" alt="Telegram"></a>
							<a class="mr-2" href="https://instagram.com/petanikode">
								<img src="https://d33wubrfki0l68.cloudfront.net/54b840aaea4637e17be2846c33facca89b5b1786/e84db/img/icon/entypo/entypo-social/instagram-with-circle.svg" width="32" height="32" alt="Instagram"></a>
							<a class="mr-2" href="https://www.youtube.com/petanikode?sub_confirmation=1">
								<img src="https://d33wubrfki0l68.cloudfront.net/d42d7ca67617a775a3fb041a2f3bb46142c85358/54521/img/icon/entypo/entypo-social/youtube-with-circle.svg" width="32" height="32" alt="Youtube"></a>
							<a class="mr-2" href="https://google.com/+PetaniKode">
								<img src="/img/icon/entypo/entypo-social/google+-with-circle.svg" width="32" height="32" alt="Google+"></a>
							<a class="mr-2" href="https://feeds.feedburner.com/petanikode">
								<img src="https://d33wubrfki0l68.cloudfront.net/c1e31ef207f98839cd488299dcee79030d771ecb/c041a/img/icon/entypo/entypo-social/rss-with-circle.svg" width="32" height="32" alt="RSS Feed">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="jumbotron jumbotron-fluid bg-dark">
		   <div class="container">
		      <div class="row">
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Database</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/codeigniter-database/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Codeigniter #5: Cara Membuat Fitur CRUD yang Benar!</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/nodejs-sqlite/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Nodejs #12: Menggunakan Database SQLite pada Nodejs</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/nodejs-mysql/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Nodejs #9: Cara Menggunakan Database MySQL pada Nodejs</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/php-login-register/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial PHP &amp; MySQL: Membuat Login dan Register (dengan Bootstrap 4)</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/java-mysql/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Java dan MySQL: Membuat Program CRUD Berbasis Teks</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/database" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Desktop</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/java-swing-click/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Pemrograman Java Swing: Bagaimana Cara Menangani Event Klik?</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/belajar-dart/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">[Tutorial Instan] Belajar Cepat Bahasa Pemrograman Dart</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/hyper/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">[Review] Hyper, Terminal Canggih untuk Programmer</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/java-swing-jendela-di-tengah-layar/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Trik Agar Jendela JFrame Selalu Tampil di Tengah Layar</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/java-desimal-biner/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Konversi Bilangan Desimal ke Bilangan Biner di Java</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/desktop" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Game</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/pygame-untuk-pemula/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Pemrograman Game dengan PyGame (Tutorial Step-by-step untuk Pemula)</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/unity3d-linux/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Pemrograman Game di Linux Menggunakan Unity3D, Apakah Bisa?</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/tutorial-html-vibrations/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Mengenal HTML5 Vibration API untuk Membuat Getaran di HP</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/html-canvas-random/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Menggambar Objek dengan Perulangan dan Fungsi Random di HTML5 Canvas</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/html-canvas/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Mengenal HTML5 Canvas untuk Pemrograman Grafis dan Game</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/game" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Iot</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/lumpy-led/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Microcontroller dengan MicroPython dan LumpyBoard</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/lumpy/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Kenalan dengan LumpyBoard, Papan Microcontroller Buatan Anak Indonesia</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/iot" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Jaringan</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/nodejs-email/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Nodejs #10: Bagaimana Cara Mengirim Email di Nodejs?</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/ssl-untuk-github-pages/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Menambahkan SSL Gratis dari Cloudflare untuk Github Pages (Kustom Domain)</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/hugo-redirect/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Redirect Halaman di Hugo untuk Mempertahankan Trafik</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/git-ftp/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Upload File ke Server FTP ala Git</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/github-ssh/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Menggunakan SSH di Github</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/jaringan" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Linux</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/menggunakan-linux-untuk-pemrograman/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Kenapa Saya Menggunakan Linux untuk Pemrograman? [Ini 5 alasannya]</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/bahasa-pemrograman-di-ubuntu/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">7 (Bahasa) Pemrograman yang Dapat Dilakukan Langsung di Ubuntu</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/programmer-buta/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Bagaimana Orang Buta Belajar Pemrograman?</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/php-cli/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Mengenal PHP CLI dan PHP Interaktif</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/pemrograman-web-di-linux/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">6 Peralatan yang Harus dipersiapkan untuk Belajar Pemrograman Web (PHP) di Linux</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/linux" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Mobile</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/ionic-untuk-pemula/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Membuat Aplikasi Android Menggunakan Ionic Framework (untuk Pemula)</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/flutter-widget/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Flutter #5: Belajar Menggunakan Widget Dasar dan Widget Layout</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/flutter-dasar/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Flutter #4: Memahami Struktur Dasar Project Aplikasi Flutter</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/flutter-android-studio/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Flutter #3: Cara Menggunakan Android Studio untuk Coding Flutter</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/flutter-1/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Keren! ini Fitur Baru di Flutter 1.0 yang akan Memudahkanmu Membuat Aplikasi</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/mobile" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Pemrograman</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/netbeans10/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Install Netbeans 10 di Linux</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/python-mysql/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Python dan MySQL: Membuat Aplikasi CRUDS Berbasis Teks</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/lumpy-led/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Microcontroller dengan MicroPython dan LumpyBoard</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/lumpy/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Kenalan dengan LumpyBoard, Papan Microcontroller Buatan Anak Indonesia</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/java-11/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Apa Saja yang Baru di Java 11?</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/pemrograman" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Tips dan trik</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/skill-programmer/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">5 Skill yang Harus dimiliki Programmer untuk Belajar Teknologi Apapun</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/belajar-pemrograman/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Bagaimana Cara Belajar Pemrograman? [ini 5 Tips yang bisa kamu coba]</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/text-editor-vscode/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">[Review] Text Editor Visual Studio Code di Linux</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/hugo-hosting-gambar/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tips dan Cara Saya Hosting Gambar untuk Hugo di Github</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/menggunakan-linux-untuk-pemrograman/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Kenapa Saya Menggunakan Linux untuk Pemrograman? [Ini 5 alasannya]</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/tips-dan-trik" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		         <div class="col-12 col-md-6 col-lg-4">
		            <div class="card-body">
		               <h4 class="card-title m-0 text-light text-center">Web</h4>
		            </div>
		            <div class="list-group list-group-flush">
		               <a href="/packagist-indonesia/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Cara Menggunakan Composer dengan Packagist Mirror Indonesia</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/codeigniter-upload/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Codeigniter #6: Membuat Fitur Upload File</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/codeigniter-database/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Tutorial Codeigniter #5: Cara Membuat Fitur CRUD yang Benar!</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/javascript-array/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Javascript: Memahami Struktur Data Array pada Javascript</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/javascript-dialog/" class="list-group-item list-group-item-action flex-column align-items-start">
		                  <div class="row">
		                     <div class="col-12">
		                        <h6 class="mb-1">Belajar Javascript: Mengenal 3 Macam Jendela Dialog pada Javascript</h6>
		                     </div>
		                  </div>
		               </a>
		               <a href="/kategori/web" class="list-group-item list-group-item-action text-center">Load More...</a>
		            </div>
		         </div>
		      </div>
		   </div>
		</div>
	</section>

	<section>
	   <div class="container my-5">
	      <div class="row">
	         <div class="col-md-4 col-sm-12"><img class="w-100 p-4 lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/fe4cffc41441237fcba237abbd72ea83997bc680/87257/img/about-section.svg" data-src="https://d33wubrfki0l68.cloudfront.net/fe4cffc41441237fcba237abbd72ea83997bc680/87257/img/about-section.svg" alt="Maskot Petani Kode"></div>
	         <div class="col-md-8 col-sm-12">
	            <h2 class="my-3">Tentang Petani Kode</h2>
	            <p>Petani Kode adalah blog yang membahas seputar dunia pemrograman dan Linux.
	               Tersedia tips dan panduan pemrograman menggunakan Linux yang bisa diikuti
	               oleh siapa saja yang tertarik melakukan pemrograman menggunakan Linux.
	               Tidak menutup kemungkinan juga, ada beberapa panduan yang menggunakan Windows.
	               <a href="/about/">Baca Selengkapnya...</a>
	            </p>
	            <p>Saat ini, topik yang sering dibahas seputar
	               <a href="/topik/php">#php</a>,
	               <a href="/topik/java">#java</a>,
	               <a href="/topik/python">#python</a>,
	               <a href="/topik/javascript">#javascript</a>,
	               dan <a href="/topik/git">#git</a>.
	            </p>
	            <a class="btn btn-primary" href="https://www.facebook.com/groups/petanikode/" target="_blank">Join Group!</a>
	            <a class="btn btn-outline-info" href="https://t.me/petani_kode" target="_blank">Ngobrol</a>
	         </div>
	      </div>
	   </div>
	</section>

	<section>
	   <div class="jumbotron jumbotron-fluid mb-0 py-5">
	      <div class="container text-center">
	         <div class="row">
	            <div class="col-12 mb-3">
	               <h4>Partner Petanikode:</h4>
	            </div>
	            <div class="col-12"><a href="https://www.rubypedia.com/" target="_blank"><img class="col-6 col-sm-4 col-xs-6 col-lg-2 lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/6cfe195149f643448eaab61ae1898e12a7620d08/97d8b/img/partner/rubypedia.png" data-src="https://d33wubrfki0l68.cloudfront.net/6cfe195149f643448eaab61ae1898e12a7620d08/97d8b/img/partner/rubypedia.png" alt="Rubypedia" title="Rubypedia"></a>
	               <a href="https://www.lombokfoss.com/" target="_blank"><img class="col-6 col-sm-4 col-xs-6 col-lg-2 lazyloaded" src="https://d33wubrfki0l68.cloudfront.net/196ca4d39a6589dbd935730ca2120374c7bd69c6/cff8d/img/partner/lombokfoss.svg" data-src="https://d33wubrfki0l68.cloudfront.net/196ca4d39a6589dbd935730ca2120374c7bd69c6/cff8d/img/partner/lombokfoss.svg" alt="Lombokfoss" title="Lombokfoss"></a>
	            </div>
	         </div>
	      </div>
	   </div>
	</section>

	<footer class="border bg-white border-bottom-0 border-left-0 border-right-0">
	   <div class="container pt-3 pb-3 pt-md-5 pb-md-5">
	      <div class="row">
	         <div class="col-md-6 col-sm-12 mb-0 mb-sm-3">
	            <ul class="nav justify-content-center justify-content-lg-start">
	               <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
	               <li class="nav-item"><a class="nav-link" href="/faqs">FAQs</a></li>
	               <li class="nav-item"><a class="nav-link" href="/about">About</a></li>
	               <li class="nav-item"><a class="nav-link" href="/advertise/">Advertise</a></li>
	               <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#contactModal">Contact</a></li>
	               <li class="nav-item"><a class="nav-link" href="/post">Arsip</a></li>
	            </ul>
	         </div>
	         <div class="col-md-6 col-sm-12 text-center text-md-right pt-2">© 2019 <a href="https://www.petanikode.com">Petani Kode</a>
	            <span class="d-none d-lg-inline">| Made with <img class="emoji" draggable="false" alt="❤️" src="https://d33wubrfki0l68.cloudfront.net/906ff572deed37cbd265a7d3980fda6105d92e95/158ab/img/icon/twemoji/2764.svg" style="width: 15px;"> using <a href="https://gohugo.io" target="_blank">Hugo 0.54.0</a></span>
	         </div>
	      </div>
	   </div>
	</footer>

	<div class="modal fade" id="contactModal" tabindex="-1" role="dialog" aria-labelledby="contactModalLabel" aria-hidden="true">
	   <div class="modal-dialog" role="document">
	      <div class="modal-content">
	         <div class="modal-header">
	            <h5 class="modal-title" id="contactModalLabel">Hubungi Kami</h5>
	            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	            <span aria-hidden="true">×</span></button>
	         </div>
	         <div class="modal-body">
	            <p>Kirim saran, kirtik, dan pertanyaan anda melalui form ini...</p>
	            <form name="contact" method="post" action="thank-you">
	               <input type="hidden" name="form-name" value="contact">
	               <p class="hidden d-none"><label>Don’t fill this out if you're human:
	                  <input name="bot-field"></label>
	               </p>
	               <div class="form-group"><label for="email">Email:</label>
	                  <input class="form-control" type="email" name="email" placeholder="email@contoh.com" required="">
	               </div>
	               <div class="form-group"><label for="message">Pesan:</label>
	                  <textarea class="form-control" name="message" placeholder="tuliskan pesan anda..." required=""></textarea>
	               </div>
	               <div class="form-group">
	                  <div>
	                     <script src="https://www.google.com/recaptcha/api.js"></script>
	                     <div class="g-recaptcha" data-sitekey="6LdAvUIUAAAAAHjrjmjtNTcXyKm0WKwefLp-dQv9">
	                        <div style="width: 304px; height: 78px;">
	                           <div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LdAvUIUAAAAAHjrjmjtNTcXyKm0WKwefLp-dQv9&amp;co=aHR0cHM6Ly93d3cucGV0YW5pa29kZS5jb206NDQz&amp;hl=en&amp;v=v1554100419869&amp;size=normal&amp;cb=pz00eumo9wcn" width="304" height="78" role="presentation" name="a-72qfo3wyu4qs" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div>
	                           <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
	                        </div>
	                     </div>
	                     <noscript>
	                        <div>
	                           <div style="width: 302px; height: 422px; position: relative;">
	                              <div style="width: 302px; height: 422px; position: absolute;">
	                                 <iframe src="https://www.google.com/recaptcha/api/fallback?k=6LdAvUIUAAAAAHjrjmjtNTcXyKm0WKwefLp-dQv9" frameborder="0" scrolling="no"
	                                    style="width: 302px; height:422px; border-style: none;">
	                                 </iframe>
	                              </div>
	                           </div>
	                           <div style="width: 300px; height: 60px; border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px;">
	                              <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response"
	                                 style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;" >
	                              </textarea>
	                           </div>
	                        </div>
	                     </noscript>
	                  </div>
	               </div>
	               <div class="form-group"><button class="btn btn-success" type="”submit”">Kirim</button></div>
	            </form>
	         </div>
	      </div>
	   </div>
	</div>
<!--.......................................................................-->
	<script type="text/javascript" src="https://d33wubrfki0l68.cloudfront.net/bundles/863fe2d987b047615946fa7e1b4381f77b40e05b.js"></script>
	<script type="text/javascript" async="" src="https://d33wubrfki0l68.cloudfront.net/js/4a9135fe7794de2463227d8b056e63f2e403b6a5/js/lazysizes.min.js"></script>
	<script type="text/javascript" src="https://d33wubrfki0l68.cloudfront.net/js/bdce53c4ca4caf4bc35a063bbd041b12452f33ab/js/twemoji.min.js"></script>
	<script>var article=document.querySelector("article");
		twemoji.parse(article,{base:"/img/icon/twemoji/",
		ext:".svg",
		callback:function(icon,options){
				return '/img/icon/twemoji/'+icon+'.svg';}});
	</script>

	<script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>(adsbygoogle=window.adsbygoogle||[]).push({google_ad_client:"ca-pub-6279325630224392",enable_page_level_ads:true});</script>

	<div id="fb-root" class=" fb_reset">
	   <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
	      <div><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="https://staticxx.facebook.com/connect/xd_arbiter/r/d_vbiawPdxB.js?version=44#channel=f293f5a94ee93f&amp;origin=https%3A%2F%2Fwww.petanikode.com" style="border: none;"></iframe></div>
	      <div></div>
	   </div>
	   <div class="fb-customerchat fb_invisible_flow fb_iframe_widget" attribution="setup_tool" page_id="143461015837500" theme_color="#008080" logged_in_greeting="Hi! Apa yang kamu cari di Petanikode?" logged_out_greeting="Hi! Apa yang kamu cari di Petanikode?" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=&amp;attribution=setup_tool&amp;container_width=0&amp;locale=id_ID&amp;logged_in_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;logged_out_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;page_id=143461015837500&amp;sdk=joey&amp;theme_color=%23008080"><span style="vertical-align: bottom; width: 1000px; height: 0px;"><iframe name="f378bed84d4e574" width="1000px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" title="" src="https://www.facebook.com/v2.12/plugins/customerchat.php?app_id=&amp;attribution=setup_tool&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2Fd_vbiawPdxB.js%3Fversion%3D44%23cb%3Df1e97d1f8266b98%26domain%3Dwww.petanikode.com%26origin%3Dhttps%253A%252F%252Fwww.petanikode.com%252Ff293f5a94ee93f%26relation%3Dparent.parent&amp;container_width=0&amp;locale=id_ID&amp;logged_in_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;logged_out_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;page_id=143461015837500&amp;sdk=joey&amp;theme_color=%23008080" style="border: none; visibility: visible; width: 288pt; height: 211px; border-radius: 9pt; bottom: 63pt; padding: 0px; position: fixed; right: 9pt; top: auto; z-index: 2147483647; max-height: 0px;" class="" data-testid="dialog_iframe"></iframe></span></div>
	   <div class="fb_dialog  fb_dialog_advanced fb_customer_chat_bubble_animated_no_badge fb_customer_chat_bubble_pop_in" style="background: none; border-radius: 50%; bottom: 18pt; display: inline; height: 45pt; padding: 0px; position: fixed; right: 18pt; top: auto; width: 45pt; z-index: 2147483646;">
	      <div class="fb_dialog_content" style="background: none;"><iframe name="blank_f378bed84d4e574" width="60px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" tabindex="-1" data-testid="bubble_iframe" src="https://staticxx.facebook.com/connect/xd_arbiter/r/d_vbiawPdxB.js?version=44#forIframe=f378bed84d4e574" style="border: none;"></iframe></div>
	   </div>
	</div>

	<div id="fb-root" class=" fb_reset">
	   <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
	      <div><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="https://staticxx.facebook.com/connect/xd_arbiter/r/d_vbiawPdxB.js?version=44#channel=f293f5a94ee93f&amp;origin=https%3A%2F%2Fwww.petanikode.com" style="border: none;"></iframe></div>
	      <div></div>
	   </div>
	   <div class="fb-customerchat fb_invisible_flow fb_iframe_widget" attribution="setup_tool" page_id="143461015837500" theme_color="#008080" logged_in_greeting="Hi! Apa yang kamu cari di Petanikode?" logged_out_greeting="Hi! Apa yang kamu cari di Petanikode?" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=&amp;attribution=setup_tool&amp;container_width=0&amp;locale=id_ID&amp;logged_in_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;logged_out_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;page_id=143461015837500&amp;sdk=joey&amp;theme_color=%23008080"><span style="vertical-align: bottom; width: 1000px; height: 0px;"><iframe name="f378bed84d4e574" width="1000px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" title="" src="https://www.facebook.com/v2.12/plugins/customerchat.php?app_id=&amp;attribution=setup_tool&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2Fd_vbiawPdxB.js%3Fversion%3D44%23cb%3Df1e97d1f8266b98%26domain%3Dwww.petanikode.com%26origin%3Dhttps%253A%252F%252Fwww.petanikode.com%252Ff293f5a94ee93f%26relation%3Dparent.parent&amp;container_width=0&amp;locale=id_ID&amp;logged_in_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;logged_out_greeting=Hi!%20Apa%20yang%20kamu%20cari%20di%20Petanikode%3F&amp;page_id=143461015837500&amp;sdk=joey&amp;theme_color=%23008080" style="border: none; visibility: visible; width: 288pt; height: 211px; border-radius: 9pt; bottom: 63pt; padding: 0px; position: fixed; right: 9pt; top: auto; z-index: 2147483647; max-height: 0px;" class="" data-testid="dialog_iframe"></iframe></span></div>
	   <div class="fb_dialog  fb_dialog_advanced fb_customer_chat_bubble_animated_no_badge fb_customer_chat_bubble_pop_in" style="background: none; border-radius: 50%; bottom: 18pt; display: inline; height: 45pt; padding: 0px; position: fixed; right: 18pt; top: auto; width: 45pt; z-index: 2147483646;">
	      <div class="fb_dialog_content" style="background: none;"><iframe name="blank_f378bed84d4e574" width="60px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" tabindex="-1" data-testid="bubble_iframe" src="https://staticxx.facebook.com/connect/xd_arbiter/r/d_vbiawPdxB.js?version=44#forIframe=f378bed84d4e574" style="border: none;"></iframe></div>
	   </div>
	</div>

	<script>(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];
		if(d.getElementById(id))
			return;js=d.createElement(s);js.id=id;js.src='https://connect.facebook.net/id_ID/sdk/xfbml.customerchat.js#xfbml=1&version=v2.12&autoLogAppEvents=1';fjs.parentNode.insertBefore(js,fjs);
				}(document,'script','facebook-jssdk'));
	</script>

	<div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;">
	   <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div>
	   <div style="margin: 0px auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid rgb(204, 204, 204); z-index: 2000000000; background-color: rgb(255, 255, 255); overflow: hidden;"><iframe title="recaptcha challenge" src="https://www.google.com/recaptcha/api2/bframe?hl=en&amp;v=v1554100419869&amp;k=6LdAvUIUAAAAAHjrjmjtNTcXyKm0WKwefLp-dQv9&amp;cb=rydmywb46z8m" name="c-72qfo3wyu4qs" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div>
	</div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>