<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Tutorial Belajar Pemrograman PHP</title>
  </head>
  <body class="bg-light">
    <!-- code disini............................... -->
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #008080;">
        <div class="container">
          <a class="navbar-brand font-weight-bold" href="http://192.168.64.2/Petani/">
          <img src="https://d33wubrfki0l68.cloudfront.net/c68e72d9d907e973e14791cdefd54fcd726a5a13/2c870/img/logo.svg" height="32" class="d-inline-block align-top" alt="Logo"> Petanikode
        </a>
        <!-- Done .................................................... -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/PHP'); ?>">PHP</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Java'); ?>">Java</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="<?= base_url('Petani/Python'); ?>">Python</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Javascript'); ?>">Javascript</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Git'); ?>">Git</a>
            </li>
            <li class="nav-item d-none d-lg-block disabled">
              <span class="nav-link disabled">|</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.youtube.com/petanikode" target="_blank"> Video</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.tees.co.id/stores/petanikode/" target="_blank">Produk</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Jobs
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="https://id.jooble.org/lowongan-kerja-programmer" title="lowongan kerja programmer" target="_blank">Loker Programmer</a>
                <a class="dropdown-item" href="http://projects.id/petani_kode" title="Remote Jobs untuk Freelancer" target="_blank">Remote Jobs</a>               
              </div>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0" action="">
            <input class="form-control mr-sm-2" type="text" name="q" placeholder="Kata Kunci" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="background-color:#17a2b8; border-color:#17a2b8; color:#fff;">Cari</button>
          </form>
        </div>
        </div>
      </nav>
    </div>
</br>
</br>
<!--....................................................................................-->
    <header>
          <div>
            <div class="jumbotron jumbotron-fluid bg-dark">
            <div class="container">
              <div class="row">
                <div class="col" style="color:#fff;">
                  <h1 class="display-4 font-weight-normal" style="font-size: 40px">Tutorial Pemrograman Python</h1>
                  <p class="lead font-weight-normal">List tutorial Python untuk Pemula dan Tingkat Mahir</p>
                </div>
              </div>
              </div>
          </div>
          </div>
      </header>

<!--.................................................................................-->
    <div class="container my-5">
     <div class="row align-items-center justify-content-center">
        <div class="col-md-12 post-outer">
           <div class="card">
              <div class="card-body p-md-5 row">
                 <div class="col-lg-9 col-sm-12">
                    <div class="post-content">
                       <h2 id="tutorial-phyton-untuk-pemula">Pemula</h2>
                       <h6>Sebelum belajar Python, pastikan kamu sudah cukup paham dengan sistem operasi terutama command line (Terminal). Karena sebagian besar dari tutorial ini menggunakan <em>command line.</em></h6>
                       <ol>
                          <li><a href="">Pengenalan Dasar Python dan Persiapan Awal yang harus dilakukan</a></li>
                          <li><a href="">Cara Install Python di Windows</a></li>
                          <li><a href="">Aturan Penulisan Sintaks Python yang Harus dipatuhi</a></li>
                          <li><a href="">Mengenal Variabel dan Tipe Data dalam Python</a></li>
                          <li><a href="">Cara Mengambil Input dan Menampilkan Output</a></li>
                          <li><a href="">Mengenal 6 Jenis Operator dalam Python</a></li>
                          <li><a href="">Memahami Percabangan dalam Python</a></li>
                          <li><a href="">Memahami Perulangan dalam Python</a></li>
                          <li><a href="">Mengenal Struktur Data List</a></li>
                          <li><a href="">Mengenal Struktur Data Tuple</a></li>
                          <li><a href="">MMengenal Struktur Data Dictionary</a></li>
                          <li><a href="">Memahami Fungsi dan Prosedur pada Python</a></li>
                          <li><a href="">Apa Maksud dari *args dan **kwargs pada Python?</a></li>
                          <li>Fungsi Anonymous atau Lambda pada Python</li>
                          <li>Python OOP: Memahami Konsep Dasar OOP pada Python</li>
                          <li>Python OOP: Inheritance/li>
                          <li>Python OOP: Hak Akses Member dalam Class (Modifier)</li>
                          <li>Python OOP: Constructor & Destructor</li>
                          <li>Python OOP: Memahami Kata Kunci self</li>
                          <li>Python OOP: Polymorfisme</li>
                          <li>Python OOP: Interface</li>
                          <li>Python OOP: Abstract</li>
                          <li>Python OOP: Exception</li>
                          <li>Python OOP: Anonymous Class</li>
                       </ol>
                       <h4 id="gift-bonus">Bonus:</h4>
                       <ul>
                          <li><a href="">Memahami fungsi max() pada python</a></li>
                          <li><a href="">Fungsi range() di pemrograman python</a></li>
                          <li><a href="">Manfaat Titik Koma pada Python yang Jarang diketahui Orang</a></li>
                          <li><a href="">Manfaat fungsi time.sleep() pada pemrograman Python</a></li>
                          <li><a href="">Membuat Program Pomodoro Timer Berbasis CLI dengan Python</a></li>
                          <li><a href="">Tips Belajar Pemrograman Python dalam Sebulan</a></li>
                          <li><a href="">Program Menghitung Tahun Kabisat dengan Python</a></li>
                       </ul>
                       <h2 id="mahir">Bagaimana Agar Mahir Python</h2>
                       <h6>Sering-sering latihan coding python. Buat program untuk studi kasus tertentu. Silahkan ikuti juga tutorial ini:</h6>
                       <ol>
                          <li><a href="">Mengenal Virtualenv: Apa Saja yang Harus Kamu Ketahui?</a></li>
                          <li><a href="">Tutorial Python dan MySQL: Membuat Aplikasi CRUDS</a></li>
                          <li><a href="">Cara Membaca dan Menulis File di Python</a></li>
                          <li><a href="">Cara Parsing Data dari JSON</a></li>
                          <li><a href=""> Parsing XML di Python dengan DOM API</a></li>
                          <li>...</li>
                          <li><a href="">Belajar Membuat Game dengan PyGame</a></li>
                          <li><a href="">Cara Membuat Graf Coding Graf dengan Python</a></li>
                       </ol>
                       <h4 id="phyton-destop">Python untuk Aplikasi Desktop</h4>
                       <ol>
                          <li><a href="">PyGTK #1: Membuat Aplikasi GUI Python dengan PyGTK</a></li>
                          <li><a href="">PyGTK #2: Membuat Tombol dan Label Teks</a></li>
                          <li><a href="">PyGTK #3: Membuat Pesan Tips (Tooltips)</a></li>
                       </ol>
                       <h4>Python untuk IoT (Internet of Things)</h4>
                       <ol>
                       		<li><a href="">Kenalan dengan LumpyBaoard, Papan Microcontroller buatan Indonesia</a></li>
                       		<li><a href="">MicroPython: Belajar Microcontroller dengan Python</a></li>
                       </ol>
                       <h2 id="ahli">Ahli</h2>
                       <ol>
                          <li><a href="">Eksperimen dengan API Simsimi</a></li>
                          <li><a href="">Belajar Membuat Web dengan Django</a></li>
                          <li>Unit Testing di Python</li>
                          <li>…</li>
                       </ol>
                       <blockquote>
                          <p>P.S: Tutorial masih belum lengkap, do’akan admin supaya tetap semangat membuat tutorial 😄 dan
                             jangan lupa di-share agar semakin banyak yang terbantu.
                          </p>
                       </blockquote>
                    </div>
                 </div>
                 <div class="col-md-3 d-none d-lg-block">
                    <h5 class="mb-3">Tutorial lainnya:</h5>
                    <div class="list-group">
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/dot-net.png')?>" width="15">
                                   </svg>
                                   .NET
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/android.png')?>" width="15">
                                   </svg>
                                   Android
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/bootstrap.png')?>" width="15">
                                   </svg>
                                   Bootstrap
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/c.png')?>" width="15">
                                   </svg>
                                   C
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/c++.png')?>" width="15">
                                   </svg>
                                   C++
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/crash.png')?>" width="15">
                                   </svg>
                                   C#
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/css.png')?>" width="15">
                                   </svg>
                                   CSS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/ci.png')?>" width="15">
                                   </svg>
                                   Codeigniter
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Git'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/git.png')?>" width="15">
                                   </svg>
                                   Git
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/HTML'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/html5.png')?>" width="15">
                                   </svg>
                                   HTML
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 410 410" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/hugo.png')?>" width="15">
                                   </svg>
                                   Hugo
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Java'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/java.png')?>" width="15">
                                   </svg>
                                   Java
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Javascript'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/javascript.png')?>" width="15">
                                   </svg>
                                   Javascript
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/laravel.png')?>" width="15">
                                   </svg>
                                   Laravel
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/mongodb.png')?>" width="15">
                                   </svg>
                                   Mongodb
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/mysql.png')?>" width="15">
                                   </svg>
                                   MySQL
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/nodejs.png')?>" width="15">
                                   </svg>
                                   Nodejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Python'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <<img src="<?= base_url('assets/img/python.png')?>" width="15">
                                   </svg>
                                   Python
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/PHP'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/php.png')?>" width="15">
                                   </svg>
                                   PHP
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/reactjs.png')?>" width="15">
                                   </svg>
                                   Reactjs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/ruby.png')?>" width="15">
                                   </svg>
                                   Ruby
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/sass.png')?>" width="15">
                                   </svg>
                                   SASS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/veujs.png')?>" width="15">
                                   </svg>
                                   Vuejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/wordpress.png')?>" width="15">
                                   </svg>
                                   Wordpress
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/yii.png')?>" width="15">
                                   </svg>
                                   Yii
                                </div>
                             </div>
                          </div>
                       </a>
                    </div>
                 </div>
              </div>
<!--....................................................................................................................................... -->
              <div class="card-footer">
                 <div class="sharethis-inline-share-buttons st-center st-has-labels  st-inline-share-buttons st-animated" id="st-1">
                    <div class="st-total ">
                       <span class="st-label"></span>
                       <span class="st-shares">
                       Shares
                       </span>
                    </div>
                    <div class="st-btn st-first" data-network="facebook" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                    <div class="st-btn" data-network="twitter" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Tweet</span>
                    </div>
                    <div class="st-btn st-last    " data-network="linkedin" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                 </div>
              </div>
              
<!--........................................................................................................................................-->
           </div>
        </div>
     </div>
  </div>

<!--Footer -->
  			<footer class="border bg-white border-bottom-0 border-left-0 border-right-0">
			   <div class="container pt-3 pb-3 pt-md-5 pb-md-5">
			      <div class="row">
			         <div class="col-md-6 col-sm-12 mb-0 mb-sm-3">
			            <ul class="nav justify-content-center justify-content-lg-start">
			               <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
			               <li class="nav-item"><a class="nav-link" href="/faqs">FAQs</a></li>
			               <li class="nav-item"><a class="nav-link" href="/about">About</a></li>
			               <li class="nav-item"><a class="nav-link" href="/advertise/">Advertise</a></li>
			               <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#contactModal">Contact</a></li>
			               <li class="nav-item"><a class="nav-link" href="/post">Arsip</a></li>
			            </ul>
			         </div>
			         <div class="col-md-6 col-sm-12 text-center text-md-right pt-2">© 2019 <a href="https://www.petanikode.com">Petani Kode</a>
			            <span class="d-none d-lg-inline">| Made with <img class="emoji" draggable="false" alt="❤️" src="https://d33wubrfki0l68.cloudfront.net/906ff572deed37cbd265a7d3980fda6105d92e95/158ab/img/icon/twemoji/2764.svg" style="width: 15px;"> using <a href="https://gohugo.io" target="_blank">Hugo 0.54.0</a></span>
			         </div>
			      </div>
			   </div>
			</footer>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>