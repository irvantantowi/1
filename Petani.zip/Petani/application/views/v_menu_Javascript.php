<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Tutorial Belajar Pemrograman Javascript</title>
  </head>
  <body class="bg-light">
    <!-- code disini............................... -->
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #008080;">
        <div class="container">
          <a class="navbar-brand font-weight-bold" href="http://192.168.64.2/Petani/">
          <img src="https://d33wubrfki0l68.cloudfront.net/c68e72d9d907e973e14791cdefd54fcd726a5a13/2c870/img/logo.svg" height="32" class="d-inline-block align-top" alt="Logo"> Petanikode
        </a>
        <!-- Done .................................................... -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/PHP'); ?>">PHP</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Java'); ?>">Java</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Python'); ?>">Python</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="<?= base_url('Petani/Javascript'); ?>">Javascript</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Git'); ?>">Git</a>
            </li>
            <li class="nav-item d-none d-lg-block disabled">
              <span class="nav-link disabled">|</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.youtube.com/petanikode" target="_blank"> Video</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.tees.co.id/stores/petanikode/" target="_blank">Produk</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Jobs
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="https://id.jooble.org/lowongan-kerja-programmer" title="lowongan kerja programmer" target="_blank">Loker Programmer</a>
                <a class="dropdown-item" href="http://projects.id/petani_kode" title="Remote Jobs untuk Freelancer" target="_blank">Remote Jobs</a>               
              </div>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0" action="">
            <input class="form-control mr-sm-2" type="text" name="q" placeholder="Kata Kunci" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="background-color:#17a2b8; border-color:#17a2b8; color:#fff;">Cari</button>
          </form>
        </div>
        </div>
      </nav>
    </div>
</br>
</br>
<!--....................................................................................-->
    <header>
          <div>
            <div class="jumbotron jumbotron-fluid bg-dark">
            <div class="container">
              <div class="row">
                <div class="col" style="color:#fff;">
                  <h1 class="display-4 font-weight-normal" style="font-size: 40px">Tutorial: Belajar Pemrograman Javascript</h1>
                  <p class="lead font-weight-normal">Javascript adalah bahasa universal yang bisa digunakan untuk membuat aplikasi web,server,desktop,mobile,game,IoT,dsb</p>
                </div>
              </div>
              </div>
          </div>
          </div>
      </header>

<!--.................................................................................-->
    <div class="container my-5">
     <div class="row align-items-center justify-content-center">
        <div class="col-md-12 post-outer">
           <div class="card">
              <div class="card-body p-md-5 row">
                 <div class="col-lg-9 col-sm-12">
                    <div class="post-content">
                       <h2 id="tutorial-php-untuk-pemula">Pemula</h2>
                       <ol>
                          <li><a href="">Tutorial Javascript #1: Pengenalan dasar Pemrograman Javascript</a></li>
                          <li><a href="">Tutorial Javascript #2: Memahami 4 Cara Penulisan Javascript pada HTML</a></li>
                          <li><a href="">Tutorial Javascript #3: Cara Menampilkan Output di Javascript</a></li>
                          <li><a href="">Tutorial Javascript #4: Variabel dan Tipe Data dalam Javascript</a></li>
                          <li><a href="">Tutorial Javascript #5: Mengenal 3 Macam Jendela Dialog pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #6: Mengenal 6 Macam Operator pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #7: Memahami 6 Bentuk Blok Percabangan pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #8: Belajar 5 Macam Jenis Blok Perulangan pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #9: Mengenal Struktur Data Array pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #10: Mengenal DOM API untuk Manipulasi HTML</a></li>
                          <li><a href="">Tutorial Javascript #11: Memahami Fungsi pada Javascript</a></li>
                          <li><a href="">Tutorial Javascript #12: Mengenal Objek di Javascript</a></li>
                          <li><a href="">Tutorial Javascript #13: Mengenal Objek Math untuk Perhitungan Matematika</a></li>
                          <li>…</li>
                       </ol>
                       <h2 id="mahir">Mahir:</h2>
                       <ol>
                       	<li><a href="/html-canvas/">Javascript &amp; Web API: Mengenal HTML5 Canvas</a></li>
                       	<li><a href="/html-canvas-random/">Javascript &amp; Web API: Menggambar Objek dengan Perulangan di HTML5 Canvas</a></li>
                       	<li><a href="/tutorial-html-vibrations/">Javascript &amp; Web API: Mengenal HTML5 Vibration API untuk Membuat Getaran di HP</a></li>
                       	<li><a href="/html-webcam/">Javascript &amp; Web API: Cara Mengakses Webcam dari HTML dan Mengambil Gambar</a></li>
                       </ol>
                       <p>Javascript dan Google Maps API:</p>
                       <ol>
                       	<li><a href="/google-map-dasar/">Tutorial Google Maps API #1: Menampilkan Peta Google Map di dalam Web</a></li>
                       	<li><a href="/google-map-marker/">Tutorial Google Maps API #2: Membuat Marker untuk Menandai Lokasi</a></li>
                       	<li><a href="/google-map-infowindow/">Tutorial Google Maps API #3: Membuat Infowindow untuk Menampilkan Informasi</a></li>
                       	<li><a href="/google-map-modal/">Mengatasi Peta (Google Map) yang tidak Ditampilkan di Modal</a></li>
                       	<li><a href="/google-map-center/">Memperbaiki Masalah Titik Tengah pada Google Maps</a></li>
                       </ol>
                       <p>Pelajari Nodejs agar semakin paham ekosistem Javascript. Berikut ini daftar tutorial Nodejs:</p>
                       <ol>
                       	<li><a href="/nodejs-pemula/">Tutorial Nodejs #1: Pengenalan Dasar Nodejs untuk Pemula</a></li><li><a href="/nodejs-npm/">Tutorial Nodejs #2: Menggunakan NPM untuk Manajemen Proyek Javascript</a></li>
                       	<li><a href="/nodejs-module/">Tutorial Nodejs #3: Cara Menggunakan Modul dalam Aplikasi Nodejs</a></li>
                       	<li><a href="/nodejs-http">Tutorial Nodejs #4: Menggunakan Modul HTTP dan URL untuk Routing</a></li>
                       	<li><a href="/nodejs-file/">Tutorial Nodejs #5: Baca Tulis File dengan Modul File System</a></li><li><a href="/nodejs-url/">Tutorial Nodejs #6: Membuat Webserver Statis dengan Modul URL</a></li>
                       	<li><a href="/nodejs-form">Tutorial Nodejs #7: Bagaimana Cara Mengambil Data dari Form?</a></li><li><a href="/nodejs-upload/">Tutorial Nodejs #8: Cara Upload File di Nodejs</a></li>
                       	<li><a href="/nodejs-mysql/">Tutorial Nodejs #9: Menggunakan Database MySQL pada Nodejs</a></li>
                       	<li><a href="/nodejs-email/">Tutorial Nodejs #10: Cara Mengirim Email dengan Nodejs</a></li>
                       	<li><a href="/nodejs-env/">Tutorial Nodejs #11: Cara Mengakses Environment Variable di Nodejs</a></li>
                       	<li><a href="/nodejs-sqlite/">Tutorial Nodejs #12: Menggunakan Database SQLite pada Nodejs</a></li>
                       	<li>…</li>
                       </ol>
                       <p>Bonus:</p>
                      <ul>
                      	<li><a href="/javascript-desktop/">7 Framework Javascript untuk Membuat Aplikasi Desktop</a></li>
                      	<li><a href="/gulp-untuk-pemula/">Tutorial Gulp untuk Pemula</a></li>
                      </ul>
                       <h2 id="ahli">Ahli</h2>
                       <ol>
                       	<li><a href="/bot-telegram-hookio/">Nodejs: Cara Membuat Bot Telegram dengan Layanan Hook.io</a></li>
                       	<li><a href="/bot-telegram-simsimi/">Nodejs: Membuat Bot Telegram Simsimi di Hook.io</a></li>
                       	<li>Belajar Framework Express</li>
                       	<li><a href="/topik/vuejs/">Belajar Framework Vuejs</a></li>
                       	<li><a href="/topik/react/">Belajar Framework React</a></li>
                       	<li>Belajar Framework Angular</li>
                       	<li>Belajar Unit Testing Javascript</li>
                       </ol>
                       <blockquote>
                          <p>P.S: Tutorial masih belum lengkap, do’akan admin supaya tetap semangat membuat tutorial 😄 dan
                             jangan lupa di-share agar semakin banyak yang terbantu.
                          </p>
                       </blockquote>
                    </div>
                 </div>
                 <div class="col-md-3 d-none d-lg-block">
                    <h5 class="mb-3">Tutorial lainnya:</h5>
                    <div class="list-group">
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/dot-net.png')?>" width="15">
                                   </svg>
                                   .NET
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/android.png')?>" width="15">
                                   </svg>
                                   Android
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/bootstrap.png')?>" width="15">
                                   </svg>
                                   Bootstrap
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/c.png')?>" width="15">
                                   </svg>
                                   C
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/c++.png')?>" width="15">
                                   </svg>
                                   C++
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/crash.png')?>" width="15">
                                   </svg>
                                   C#
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/css.png')?>" width="15">
                                   </svg>
                                   CSS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/ci.png')?>" width="15">
                                   </svg>
                                   Codeigniter
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Git'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/git.png')?>" width="15">
                                   </svg>
                                   Git
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/HTML'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/html5.png')?>" width="15">
                                   </svg>
                                   HTML
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 410 410" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/hugo.png')?>" width="15">
                                   </svg>
                                   Hugo
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Java'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/java.png')?>" width="15">
                                   </svg>
                                   Java
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Javascript'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/javascript.png')?>" width="15">
                                   </svg>
                                   Javascript
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/laravel.png')?>" width="15">
                                   </svg>
                                   Laravel
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/mongodb.png')?>" width="15">
                                   </svg>
                                   Mongodb
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/mysql.png')?>" width="15">
                                   </svg>
                                   MySQL
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/nodejs.png')?>" width="15">
                                   </svg>
                                   Nodejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Python'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <<img src="<?= base_url('assets/img/python.png')?>" width="15">
                                   </svg>
                                   Python
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/PHP'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/php.png')?>" width="15">
                                   </svg>
                                   PHP
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/reactjs.png')?>" width="15">
                                   </svg>
                                   Reactjs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/ruby.png')?>" width="15">
                                   </svg>
                                   Ruby
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/sass.png')?>" width="15">
                                   </svg>
                                   SASS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/veujs.png')?>" width="15">
                                   </svg>
                                   Vuejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/wordpress.png')?>" width="15">
                                   </svg>
                                   Wordpress
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/yii.png')?>" width="15">
                                   </svg>
                                   Yii
                                </div>
                             </div>
                          </div>
                       </a>
                    </div>
                 </div>
              </div>
<!--....................................................................................................................................... -->
              <div class="card-footer">
                 <div class="sharethis-inline-share-buttons st-center st-has-labels  st-inline-share-buttons st-animated" id="st-1">
                    <div class="st-total ">
                       <span class="st-label"></span>
                       <span class="st-shares">
                       Shares
                       </span>
                    </div>
                    <div class="st-btn st-first" data-network="facebook" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                    <div class="st-btn" data-network="twitter" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Tweet</span>
                    </div>
                    <div class="st-btn st-last    " data-network="linkedin" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                 </div>
              </div>
<!--........................................................................................................................................-->
           </div>
        </div>
     </div>
  </div>

  <!--Footer -->
        <footer class="border bg-white border-bottom-0 border-left-0 border-right-0">
         <div class="container pt-3 pb-3 pt-md-5 pb-md-5">
            <div class="row">
               <div class="col-md-6 col-sm-12 mb-0 mb-sm-3">
                  <ul class="nav justify-content-center justify-content-lg-start">
                     <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                     <li class="nav-item"><a class="nav-link" href="/faqs">FAQs</a></li>
                     <li class="nav-item"><a class="nav-link" href="/about">About</a></li>
                     <li class="nav-item"><a class="nav-link" href="/advertise/">Advertise</a></li>
                     <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#contactModal">Contact</a></li>
                     <li class="nav-item"><a class="nav-link" href="/post">Arsip</a></li>
                  </ul>
               </div>
               <div class="col-md-6 col-sm-12 text-center text-md-right pt-2">© 2019 <a href="https://www.petanikode.com">Petani Kode</a>
                  <span class="d-none d-lg-inline">| Made with <img class="emoji" draggable="false" alt="❤️" src="https://d33wubrfki0l68.cloudfront.net/906ff572deed37cbd265a7d3980fda6105d92e95/158ab/img/icon/twemoji/2764.svg" style="width: 15px;"> using <a href="https://gohugo.io" target="_blank">Hugo 0.54.0</a></span>
               </div>
            </div>
         </div>
      </footer>






    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>