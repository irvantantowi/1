<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Tutorial Belajar Pemrograman PHP</title>
  </head>
  <body class="bg-light">
    <!-- code disini............................... -->
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #008080;">
        <div class="container">
          <a class="navbar-brand font-weight-bold" href="http://192.168.64.2/Petani/">
          <img src="https://d33wubrfki0l68.cloudfront.net/c68e72d9d907e973e14791cdefd54fcd726a5a13/2c870/img/logo.svg" height="32" class="d-inline-block align-top" alt="Logo"> Petanikode
        </a>
        <!-- Done .................................................... -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/PHP'); ?>">PHP</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="<?= base_url('Petani/Java'); ?>">Java</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Python'); ?>">Python</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Javascript'); ?>">Javascript</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('Petani/Git'); ?>">Git</a>
            </li>
            <li class="nav-item d-none d-lg-block disabled">
              <span class="nav-link disabled">|</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.youtube.com/petanikode" target="_blank"> Video</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.tees.co.id/stores/petanikode/" target="_blank">Produk</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Jobs
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="https://id.jooble.org/lowongan-kerja-programmer" title="lowongan kerja programmer" target="_blank">Loker Programmer</a>
                <a class="dropdown-item" href="http://projects.id/petani_kode" title="Remote Jobs untuk Freelancer" target="_blank">Remote Jobs</a>               
              </div>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0" action="">
            <input class="form-control mr-sm-2" type="text" name="q" placeholder="Kata Kunci" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="background-color:#17a2b8; border-color:#17a2b8; color:#fff;">Cari</button>
          </form>
        </div>
        </div>
      </nav>
    </div>
</br>
</br>
<!--....................................................................................-->
    <header>
          <div>
            <div class="jumbotron jumbotron-fluid bg-dark">
            <div class="container">
              <div class="row">
                <div class="col" style="color:#fff;">
                  <h1 class="display-4 font-weight-normal" style="font-size: 40px">Tutorial Pemrograman Java dari Nol Hingga Mahir</h1>
                  <p class="lead font-weight-normal">Java adalah bahasa pemrograman OOP untuk membuat Aplikasi Desktop, Web, dan Android</p>
                </div>
              </div>
              </div>
          </div>
          </div>
      </header>

<!--.................................................................................-->
    <div class="container my-5">
     <div class="row align-items-center justify-content-center">
        <div class="col-md-12 post-outer">
           <div class="card">
              <div class="card-body p-md-5 row">
                 <div class="col-lg-9 col-sm-12">
                    <div class="post-content">
                       <h2 id="tutorial-java-untuk-pemula">Tutorial Java untuk Pemula</h2>
                       <ol>
                          <li><a href="">Tutorial Java #01: Persiapan Awal yang Harus dilakukan untuk Pemrograman Java</a></li>
                          <li><a href="">Tutorial Java #02: Membuat Program Java Pertama</a> </li>
                          <li><a href="">Tutorial Java #03: Memahami Struktur dan Arturan Penulisan Sintaks Java</a></li>
                          <li><a href="">Tutorial Java #04: Mengenal Variabel dan Tipe Data</a></li>
                          <li><a href="">Tutorial Java #05: Input dan Output pada Java</a></li>
                          <li><a href="">Tutorial Java #06: Memahami Operator Dasar pada Java</a></li>
                          <li><a href="">Tutorial Java #07: Cara Menghitung Operasi Pangkat</a></li>
                          <li><a href="">Tutorial Java #08: Memahami Blok Percabangan dalam Program Java</a></li>
                          <li><a href="">Tutorial Java #09: Memahami Blok Perulangan pada Java</a></li>
                          <li><a href="">Tutorial Java #10: Mengenal dan Memahami Struktur Data Array dan Array List</a></li>
                          <li><a href="">Tutorial Java #11: Mengenal dan Memahami Fungsi di Java</a></li>
                          <li><a href="">Tutorial Java #12: Menggunakan Struktur Data Hashmap</a></li>
                          <li>....</li>
                       </ol>
                       <h4 id="pemula-oop">Tutorial Java OOP untuk Pemula</h4>
                       <h6>Java merupakan bahasa pemrograman yang menggunakan paradigma OOP (Object Oriented Programming). Oleh sebab itu, kita harus belajar konsep OOP pada Java.</h6>
                       <h6>Berikut ini tutorial OOP Java:</h6>
                       <ol>
                          <li><a href="">Tutorial Java OOP #1: Memahami Konsep Dasar OOP pada Java</a></li>
                          <li><a href="">Tutorial Java OOP #2: Inheritance dan Method Overriding</a></li>
                          <li><a href="">Tutorial Java OOP #2: Inheritance dan Method Overriding</a></li>
                          <li><a href="">Tutorial Java OOP #4: Constructor & Destructor pada Java</a></li>
                          <li><a href="">Tutorial Java OOP #5: Menggunakan Method Setter dan Getter</a></li>
                          <li><a href="">Tutorial Java OOP #6: Memahami Kata Kunci this dan super</a></li>
                          <li>Tutorial Java OOP #7: Polymorfisme dan Method Overloading</li>
                          <li>Tutorial Java OOP #8: Menggunakan Interface</li>
                          <li>Tutorial Java OOP #9: Mengenal Class Abstract</li>
                          <li>Tutorial Java OOP #10: Exception untuk Mengatasi Error</li>
                          <li>Tutorial Java OOP #11: Anonymous Class</li>
                          <li>...</li>
                       </ol>
                       <h4 id="gift-bonus">🎁 Bonus: Tips dan Informasi Menarik tentang Java</h4>
                       <ul>
                          <li><a href="">Apa Saja Fitur terbaru di Java 11?</a></li>
                          <li><a href="">Cara Install Netbeans 10 di Linux</a></li>
                          <li><a href="">Kenapa Bahasa Pemrograman Java Kurang Cocok untuk Pemula?</a></li>
                          <li><a href="">Cara Mengatasi JDK yang Lebih dari Satu di Linux agar tidak Bentrok</a></li>
                          <li><a href="">Pilihan Alternatif Java dan Symbolic Link yang Buntu</a></li>
                          <li><a href="">Operator ^ (xor) di Java bukan untuk Membuat Pangkat</a></li>
                          <li><a href="">Menghitung Akar Kuadrat dan Akar Kubik dengan Java</a></li>
                          <li><a href="">Apa Fungsi String[] args pada Pemrograman Java?</a></li>
                       </ul>
                       <h2 id="mahir">Supaya Mahir Java</h2>
                       <h6>Sering-sering latihan dengan studi kasus tertentu…</h6>
                       <ol>
                          <li>Membaca dan Menulis File dengan Java</li>
                          <li><a href="">Belajar Java Swing: Membuat Jendela dengan JFrame</a></li>
                          <li><a href="">Belajar Java Swing: Cara Menggunakan JOptionPane untuk Membuat Dialog</a></li>
                          <li><a href="">Belajar Java Swing: Trik Agar Jendela JFrame Selalu Tampil di Tengah Layar</a></li>
                          <li><a href="">Belajar Java Swing: Menangani Event Klik pada Program Java Swing</a></li>
                          <li>...</li>
                          <li><a href="">Belajar Menggunakan Java dan Database MySQL</a></li>
                          <li>Membuat Aplikasi CRUD dengan Java Swing dan MySQL</li>
                          <li>Membuat Aplikasi CRUD dengan Java Swing dan SQLite</li>
                          <li>Pengolahan Citra dengan Java</li>
                          <li>Pemrograman Grafika Komputer dengan Java</li>
                          <li>Membuat Aplikasi Jaringan dengan Java</li>
                       </ol>
                       <h4 id="gift-bonus-1">🎁 Bonus:</h4>
                       <ul>
                          <li><a href="">Konversi Bilangan Desimal ke Bilangan Biner di Java</a></li>
                       </ul>
                       <h2 id="ahli">Menjadi Expert di Java</h2>
                       <ol>
                          <li><a href="">Cara Menggunakan Maven pada Proyek Aplikasi Java</a></li>
                          <li>Cara Menggunakan Gradle pada Proyek Aplikasi Java</li>
                          <li><a href="">Belajar Menggunakan GSON untuk Serialisasi dan Deserialisasi Data JSON New</a></li>
                          <li><a href="">Belajar Pemrograman Android</a></li>
                          <li>Belajar Spring Framework</li>
                          <li>Belajar Membuat RESTful API dengan Java</li>
                          <li>Belajar Menerapkan JWT</li>
                          <li>Memahami Konsep Depedency Injection</li>
                          <li>Deploy Aplikasi Java di Heroku</li>
                          <li>Membuat Bot Telegram dengan Java</li>
                          <li>Menggunakan JUnit untuk Unit Testing</li>
                          <li>..</li>
                       </ol>
                       <blockquote>
                          <p>P.S: Tutorial masih belum lengkap, do’akan admin supaya tetap semangat membuat tutorial 😄 dan
                             jangan lupa di-share agar semakin banyak yang terbantu.
                          </p>
                       </blockquote>
                    </div>
                 </div>
                 <div class="col-md-3 d-none d-lg-block">
                    <h5 class="mb-3">Tutorial lainnya:</h5>
                    <div class="list-group">
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/dot-net.png')?>" width="15">
                                   </svg>
                                   .NET
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/android.png')?>" width="15">
                                   </svg>
                                   Android
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/bootstrap.png')?>" width="15">
                                   </svg>
                                   Bootstrap
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/c.png')?>" width="15">
                                   </svg>
                                   C
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/c++.png')?>" width="15">
                                   </svg>
                                   C++
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/crash.png')?>" width="15">
                                   </svg>
                                   C#
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/css.png')?>" width="15">
                                   </svg>
                                   CSS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/ci.png')?>" width="15">
                                   </svg>
                                   Codeigniter
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Git'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/git.png')?>" width="15">
                                   </svg>
                                   Git
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/HTML'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/html5.png')?>" width="15">
                                   </svg>
                                   HTML
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 410 410" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/hugo.png')?>" width="15">
                                   </svg>
                                   Hugo
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Java'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/java.png')?>" width="15">
                                   </svg>
                                   Java
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Javascript'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/javascript.png')?>" width="15">
                                   </svg>
                                   Javascript
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/laravel.png')?>" width="15">
                                   </svg>
                                   Laravel
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/mongodb.png')?>" width="15">
                                   </svg>
                                   Mongodb
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/mysql.png')?>" width="15">
                                   </svg>
                                   MySQL
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/nodejs.png')?>" width="15">
                                   </svg>
                                   Nodejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/Python'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <<img src="<?= base_url('assets/img/python.png')?>" width="15">
                                   </svg>
                                   Python
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="<?= base_url('Petani/PHP'); ?>" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/php.png')?>" width="15">
                                   </svg>
                                   PHP
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/reactjs.png')?>" width="15">
                                   </svg>
                                   Reactjs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <<img src="<?= base_url('assets/img/ruby.png')?>" width="15">
                                   </svg>
                                   Ruby
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/sass.png')?>" width="15">
                                   </svg>
                                   SASS
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/veujs.png')?>" width="15">
                                   </svg>
                                   Vuejs
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                     <!-- Tinggal masukin icon -->
                                     <img src="<?= base_url('assets/img/wordpress.png')?>" width="15">
                                   </svg>
                                   Wordpress
                                </div>
                             </div>
                          </div>
                       </a>
                       <a href="" class="list-group-item list-group-item-action">
                          <div class="row">
                             <div class="col-12">
                                <div class="align-middle">
                                   <svg viewBox="0 0 128 128" class="d-inline icon" style="width: 24px">
                                      <!-- Tinggal masukin icon -->
                                      <img src="<?= base_url('assets/img/yii.png')?>" width="15">
                                   </svg>
                                   Yii
                                </div>
                             </div>
                          </div>
                       </a>
                    </div>
                 </div>
              </div>
<!--....................................................................................................................................... -->
              <div class="card-footer">
                 <div class="sharethis-inline-share-buttons st-center st-has-labels  st-inline-share-buttons st-animated" id="st-1">
                    <div class="st-total ">
                       <span class="st-label"></span>
                       <span class="st-shares">
                       Shares
                       </span>
                    </div>
                    <div class="st-btn st-first" data-network="facebook" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                    <div class="st-btn" data-network="twitter" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Tweet</span>
                    </div>
                    <div class="st-btn st-last    " data-network="linkedin" style="display: inline-block;">
                       <svg fill="#fff" preserveAspectRatio="xMidYMid meet" height="1em" width="1em" viewBox="0 0 40 40">
                          
                       </svg>
                       <span class="st-label">Share</span>
                    </div>
                 </div>
              </div>
              

<!--........................................................................................................................................-->
           </div>
        </div>
     </div>
  </div>

  <!--Footer -->
        <footer class="border bg-white border-bottom-0 border-left-0 border-right-0">
         <div class="container pt-3 pb-3 pt-md-5 pb-md-5">
            <div class="row">
               <div class="col-md-6 col-sm-12 mb-0 mb-sm-3">
                  <ul class="nav justify-content-center justify-content-lg-start">
                     <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                     <li class="nav-item"><a class="nav-link" href="/faqs">FAQs</a></li>
                     <li class="nav-item"><a class="nav-link" href="/about">About</a></li>
                     <li class="nav-item"><a class="nav-link" href="/advertise/">Advertise</a></li>
                     <li class="nav-item"><a class="nav-link" href="#!" data-toggle="modal" data-target="#contactModal">Contact</a></li>
                     <li class="nav-item"><a class="nav-link" href="/post">Arsip</a></li>
                  </ul>
               </div>
               <div class="col-md-6 col-sm-12 text-center text-md-right pt-2">© 2019 <a href="https://www.petanikode.com">Petani Kode</a>
                  <span class="d-none d-lg-inline">| Made with <img class="emoji" draggable="false" alt="❤️" src="https://d33wubrfki0l68.cloudfront.net/906ff572deed37cbd265a7d3980fda6105d92e95/158ab/img/icon/twemoji/2764.svg" style="width: 15px;"> using <a href="https://gohugo.io" target="_blank">Hugo 0.54.0</a></span>
               </div>
            </div>
         </div>
      </footer>






    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>